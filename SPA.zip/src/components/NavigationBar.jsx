import { AuthenticatedTemplate, UnauthenticatedTemplate, useMsal } from "@azure/msal-react";

import { Nav, Navbar, Button, Dropdown, DropdownButton} from "react-bootstrap";

import { loginRequest } from "../authConfig";

export const NavigationBar = () => {

    const { instance } = useMsal();

    /**
     * Most applications will need to conditionally render certain components based on whether a user is signed in or not. 
     * msal-react provides 2 easy ways to do this. AuthenticatedTemplate and UnauthenticatedTemplate components will 
     * only render their children if a user is authenticated or unauthenticated, respectively.
     */
    return (
        <>
            <Navbar bg="primary" variant="dark">
                <a className="navbar-brand" href="/">Microsoft identity platform</a>
                <AuthenticatedTemplate>
                    <Nav.Link as={Button} href="/admin">Admin</Nav.Link>
                    <Nav.Link as={Button} href="/user">User</Nav.Link>
                    <Nav.Link variant="secondary" className="ml-auto" drop="left" as="button" onClick={() => instance.logoutRedirect({ postLogoutRedirectUri: "/" })}>Sign out</Nav.Link>
                </AuthenticatedTemplate>
                <UnauthenticatedTemplate>
                    <Nav.Link variant="secondary" className="ml-auto" drop="left" as="button" onClick={() => instance.loginRedirect(loginRequest)}>Sign in</Nav.Link>
                </UnauthenticatedTemplate>
            </Navbar>
        </>
    );
};