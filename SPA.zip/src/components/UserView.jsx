import ListGroup from "react-bootstrap/ListGroup";
import ListGroupItem from "react-bootstrap/ListGroupItem";


export const UserView = (props) => {
    const weather = props.userData;
    const weatherList = (
        <ListGroupItem >
        <p>{weather.date}</p>
        <p>{weather.temperatureC}</p>
        <p>{weather.temperatureF}</p>
        <p>{weather.summary}</p>
    </ListGroupItem>
    );

    return (
        <div className="data-area-div">
            <ListGroup className="todo-list">
                {weatherList}
            </ListGroup>
        </div>
    );
}
