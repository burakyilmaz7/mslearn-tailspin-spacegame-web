/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { protectedResources } from "./authConfig";
import { msalInstance } from "./index";

const getToken = async () => {
    const account = msalInstance.getActiveAccount();

    if (!account) {
        throw Error("No active account! Verify a user has been signed in and setActiveAccount has been called.");
    }

    const response = await msalInstance.acquireTokenSilent({
        account: account,
        ...protectedResources.apiDemo.scopes
    });

    return response.accessToken;
}

export const getWeatherList = async () => {
    const accessToken = await getToken();

    const headers = new Headers();
    const bearer = `Bearer ${accessToken}`;

    headers.append("Authorization", bearer);

    const options = {
        method: "GET",
        headers: headers
    };

    return fetch(protectedResources.apiDemo.adminEndpoint, options)
        .then(response => response.json())
        .catch(error => console.log(error));
}

export const getWeather = async () => {
    const accessToken = await getToken();

    const headers = new Headers();
    const bearer = `Bearer ${accessToken}`;

    headers.append("Authorization", bearer);

    const options = {
        method: "GET",
        headers: headers
    };

    return fetch(protectedResources.apiDemo.userEndpoint, options)
        .then(response => response.json())
        .catch(error => console.log(error));
}


